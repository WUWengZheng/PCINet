from PIL import Image
import os
import glob
import torchvision.transforms as transforms
from torchvision.transforms import InterpolationMode
import torch.utils.data
import random
import torchvision.transforms.functional as tf

root_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'LEVIR-CD')


def read_images(root):
    train_a_path = os.path.join(root, 'train', 'A')
    train_b_path = os.path.join(root, 'train', 'B')
    train_label_path = os.path.join(root, 'train', 'label')
    test_a_path = os.path.join(root, 'test', 'A')
    test_b_path = os.path.join(root, 'test', 'B')
    test_label_path = os.path.join(root, 'test', 'label')
    
    imgs_At = glob.glob(os.path.join(train_a_path, '*.png')) + glob.glob(os.path.join(train_a_path, '*.jpg')) + glob.glob(os.path.join(train_a_path, '*.jpeg'))
    imgs_Bt = glob.glob(os.path.join(train_b_path, '*.png')) + glob.glob(os.path.join(train_b_path, '*.jpg')) + glob.glob(os.path.join(train_b_path, '*.jpeg'))
    labelst = glob.glob(os.path.join(train_label_path, '*.png')) + glob.glob(os.path.join(train_label_path, '*.jpg')) + glob.glob(os.path.join(train_label_path, '*.jpeg'))
    imgs_Att = glob.glob(os.path.join(test_a_path, '*.png')) + glob.glob(os.path.join(test_a_path, '*.jpg')) + glob.glob(os.path.join(test_a_path, '*.jpeg'))
    imgs_Btt = glob.glob(os.path.join(test_b_path, '*.png')) + glob.glob(os.path.join(test_b_path, '*.jpg')) + glob.glob(os.path.join(test_b_path, '*.jpeg'))
    labelstt = glob.glob(os.path.join(test_label_path, '*.png')) + glob.glob(os.path.join(test_label_path, '*.jpg')) + glob.glob(os.path.join(test_label_path, '*.jpeg'))
    
    imgs_At.sort()
    imgs_Bt.sort()
    labelst.sort()
    imgs_Att.sort()
    imgs_Btt.sort()
    labelstt.sort()
    
    return imgs_At, imgs_Bt, labelst, imgs_Att, imgs_Btt, labelstt


def rotate_triplet(before, after, change, angle):
    before = tf.rotate(
        before, angle, interpolation=InterpolationMode.BILINEAR, expand=False, fill=0
    )
    after = tf.rotate(
        after, angle, interpolation=InterpolationMode.BILINEAR, expand=False, fill=0
    )
    change = tf.rotate(
        change, angle, interpolation=InterpolationMode.NEAREST, expand=False, fill=0
    )
    return before, after, change


# ImageNet 归一化参数（与 pretrained MobileNetV2 匹配）
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def imagestransforms(before, after, change):
    # 离散旋转：只从 0, 90, 180, 270 中随机选择
    angles = [0, 90, 180, 270]
    angle = random.choice(angles)
    before, after, change = rotate_triplet(before, after, change, angle)

    # 随机水平翻转
    if random.random() > 0.5:
        before = tf.hflip(before)
        after = tf.hflip(after)
        change = tf.hflip(change)

    # 随机垂直翻转
    if random.random() > 0.5:
        before = tf.vflip(before)
        after = tf.vflip(after)
        change = tf.vflip(change)

    # 同步轻量颜色扰动：before/after 共享同一组参数
    brightness_factor = random.uniform(0.9, 1.1)
    contrast_factor = random.uniform(0.9, 1.1)
    saturation_factor = random.uniform(0.9, 1.1)
    before = tf.adjust_brightness(before, brightness_factor)
    after = tf.adjust_brightness(after, brightness_factor)
    before = tf.adjust_contrast(before, contrast_factor)
    after = tf.adjust_contrast(after, contrast_factor)
    before = tf.adjust_saturation(before, saturation_factor)
    after = tf.adjust_saturation(after, saturation_factor)

    # 同步轻量高斯模糊：小概率、共享同一组参数
    if random.random() < 0.2:
        sigma = random.uniform(0.1, 1.0)
        before = tf.gaussian_blur(before, kernel_size=[3, 3], sigma=[sigma, sigma])
        after = tf.gaussian_blur(after, kernel_size=[3, 3], sigma=[sigma, sigma])

    # to_tensor 转换到 [0, 1]，然后归一化
    before = tf.to_tensor(before)
    after = tf.to_tensor(after)
    change = tf.to_tensor(change)

    # ImageNet 归一化（针对 RGB 图像）
    normalize = transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    before = normalize(before)
    after = normalize(after)

    return before, after, change


def images_transforms(before, after, change):
    before, after, change = imagestransforms(before, after, change)
    return before, after, change


def images_transforms_(before, after, change):
    before = tf.to_tensor(before)
    after = tf.to_tensor(after)
    change = tf.to_tensor(change)

    # 测试阶段同样需要 ImageNet 归一化
    normalize = transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    before = normalize(before)
    after = normalize(after)

    return before, after, change


class LEVIRDataset(torch.utils.data.Dataset):
    def __init__(self, mode='train'):
        self.mode = mode
        if not os.path.isdir(root_path):
            candidates = [
                os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'datasets', 'LEVIR-CD')),
                os.path.abspath(os.path.join(os.getcwd(), 'datasets', 'LEVIR-CD')),
            ]
            for cand in candidates:
                if os.path.isdir(cand):
                    root = cand
                    break
            else:
                root = root_path
        else:
            root = root_path

        self.train_dataset_before, self.train_dataset_after, self.train_dataset_change, self.test_dataset_before, self.test_dataset_after, self.test_dataset_change = read_images(root)
        if mode == 'train':
            print('训练集加载了' + str(len(self.train_dataset_before)) + '张图片')
            if len(self.train_dataset_before) == 0:
                raise RuntimeError(
                    'LEVIRDataset: 未找到训练数据。\n'
                    'root_path=' + str(root) + '\n'
                    '请检查 train/A、train/B、train/label 目录是否存在，且图片后缀为 png/jpg/jpeg。'
                )
            if len(self.train_dataset_before) != len(self.train_dataset_after) or len(self.train_dataset_before) != len(self.train_dataset_change):
                raise RuntimeError(
                    'LEVIRDataset: 训练数据目录图片数量不一致。\n'
                    'train/A: ' + str(len(self.train_dataset_before)) + '张\n'
                    'train/B: ' + str(len(self.train_dataset_after)) + '张\n'
                    'train/label: ' + str(len(self.train_dataset_change)) + '张\n'
                    '请确保三个目录包含相同数量的图片。'
                )
        elif mode == 'test':
            print('测试集加载了' + str(len(self.test_dataset_before)) + '张图片')
            if len(self.test_dataset_before) == 0:
                raise RuntimeError(
                    'LEVIRDataset: 未找到测试数据。\n'
                    'root_path=' + str(root) + '\n'
                    '请检查 test/A、test/B、test/label 目录是否存在，且图片后缀为 png/jpg/jpeg。'
                )
            if len(self.test_dataset_before) != len(self.test_dataset_after) or len(self.test_dataset_before) != len(self.test_dataset_change):
                raise RuntimeError(
                    'LEVIRDataset: 测试数据目录图片数量不一致。\n'
                    'test/A: ' + str(len(self.test_dataset_before)) + '张\n'
                    'test/B: ' + str(len(self.test_dataset_after)) + '张\n'
                    'test/label: ' + str(len(self.test_dataset_change)) + '张\n'
                    '请确保三个目录包含相同数量的图片。'
                )

    def __getitem__(self, item):
        if self.mode == 'train':
            before = Image.open(self.train_dataset_before[item]).convert('RGB')
            after = Image.open(self.train_dataset_after[item]).convert('RGB')
            change = Image.open(self.train_dataset_change[item]).convert('L')
            before, after, change = images_transforms(before, after, change)
            return before, after, change
        elif self.mode == 'test':
            before = Image.open(self.test_dataset_before[item]).convert('RGB')
            after = Image.open(self.test_dataset_after[item]).convert('RGB')
            change = Image.open(self.test_dataset_change[item]).convert('L')
            before, after, change = images_transforms_(before, after, change)
            return before, after, change

    def __len__(self):
        if self.mode == 'train':
            return len(self.train_dataset_before)
        elif self.mode == 'test':
            return len(self.test_dataset_before)


if __name__ == '__main__':
    print('Testing LEVIRDataset...')
    try:
        train_data = LEVIRDataset(mode='train')
        print(f'Training dataset loaded: {len(train_data)} samples')
        
        test_data = LEVIRDataset(mode='test')
        print(f'Test dataset loaded: {len(test_data)} samples')
        
        before, after, change = train_data[0]
        print(f'First sample shape - before: {before.shape}, after: {after.shape}, change: {change.shape}')
        print(f'Before stats: min={before.min():.4f}, max={before.max():.4f}, mean={before.mean():.4f}')
        
        print('All tests passed!')
    except Exception as e:
        print(f'Error: {e}')
        import traceback
        traceback.print_exc()
