from pathlib import Path
import os
import random

from PIL import Image
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.transforms.functional as tf
from torchvision.transforms import InterpolationMode


IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}
LABEL_DIR_NAMES = ('label', 'labels', 'OUT', 'out', 'gt', 'GT', 'mask', 'masks')
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]
DEFAULT_INPUT_SIZE = 256


def _repo_root():
    return Path(__file__).resolve().parents[1]


def _candidate_roots(root):
    if root:
        yield Path(root)

    for env_key in ('SYSUCD_ROOT', 'SYSU_CD_ROOT', 'DATA_ROOT'):
        env_value = os.environ.get(env_key)
        if env_value:
            base = Path(env_value)
            yield base
            yield base / 'SYSU-CD'
            yield base / 'SYSUCD'

    names = ('SYSU-CD', 'SYSUCD', 'SYSU_CD')
    bases = (
        _repo_root(),
        _repo_root() / 'datasets',
        Path.cwd(),
        Path.cwd() / 'datasets',
    )
    for base in bases:
        for name in names:
            yield base / name


def _resolve_root(root=None):
    seen = set()
    candidates = []
    for candidate in _candidate_roots(root):
        candidate = candidate.expanduser().resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        candidates.append(candidate)
        if candidate.is_dir():
            return candidate
    return candidates[0] if candidates else _repo_root() / 'SYSU-CD'


def _image_files(folder):
    folder = Path(folder)
    if not folder.is_dir():
        return []
    return sorted(
        [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS],
        key=lambda p: p.name.lower(),
    )


def _find_label_dir(split_root):
    for dirname in LABEL_DIR_NAMES:
        label_dir = split_root / dirname
        if label_dir.is_dir():
            return label_dir
    return split_root / 'label'


def _match_triplets(a_files, b_files, label_files):
    a_map = {p.stem.lower(): p for p in a_files}
    b_map = {p.stem.lower(): p for p in b_files}
    label_map = {p.stem.lower(): p for p in label_files}
    keys = sorted(set(a_map) & set(b_map) & set(label_map))
    return [a_map[k] for k in keys], [b_map[k] for k in keys], [label_map[k] for k in keys]


def _read_split(root, split):
    split_root = Path(root) / split
    a_dir = split_root / 'A'
    b_dir = split_root / 'B'
    label_dir = _find_label_dir(split_root)
    return _match_triplets(_image_files(a_dir), _image_files(b_dir), _image_files(label_dir))


def read_images(root):
    root = Path(root)
    train_a, train_b, train_label = _read_split(root, 'train')

    eval_split = 'test'
    if not (root / 'test').is_dir() and (root / 'val').is_dir():
        eval_split = 'val'
    test_a, test_b, test_label = _read_split(root, eval_split)

    return train_a, train_b, train_label, test_a, test_b, test_label


def _resize_triplet(before, after, change, input_size):
    if input_size is None:
        return before, after, change
    size = [int(input_size), int(input_size)]
    before = tf.resize(before, size, interpolation=InterpolationMode.BILINEAR)
    after = tf.resize(after, size, interpolation=InterpolationMode.BILINEAR)
    change = tf.resize(change, size, interpolation=InterpolationMode.NEAREST)
    return before, after, change


def rotate_triplet(before, after, change, angle):
    before = tf.rotate(before, angle, interpolation=InterpolationMode.BILINEAR, expand=False, fill=0)
    after = tf.rotate(after, angle, interpolation=InterpolationMode.BILINEAR, expand=False, fill=0)
    change = tf.rotate(change, angle, interpolation=InterpolationMode.NEAREST, expand=False, fill=0)
    return before, after, change


def _to_tensor_and_normalize(before, after, change):
    before = tf.to_tensor(before)
    after = tf.to_tensor(after)
    change = (tf.to_tensor(change) > 0.5).float()

    normalize = transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    before = normalize(before)
    after = normalize(after)
    return before, after, change


def imagestransforms(before, after, change, input_size=DEFAULT_INPUT_SIZE):
    before, after, change = _resize_triplet(before, after, change, input_size)

    angle = random.choice([0, 90, 180, 270])
    before, after, change = rotate_triplet(before, after, change, angle)

    if random.random() > 0.5:
        before = tf.hflip(before)
        after = tf.hflip(after)
        change = tf.hflip(change)

    if random.random() > 0.5:
        before = tf.vflip(before)
        after = tf.vflip(after)
        change = tf.vflip(change)

    brightness_factor = random.uniform(0.9, 1.1)
    contrast_factor = random.uniform(0.9, 1.1)
    saturation_factor = random.uniform(0.9, 1.1)
    before = tf.adjust_brightness(before, brightness_factor)
    after = tf.adjust_brightness(after, brightness_factor)
    before = tf.adjust_contrast(before, contrast_factor)
    after = tf.adjust_contrast(after, contrast_factor)
    before = tf.adjust_saturation(before, saturation_factor)
    after = tf.adjust_saturation(after, saturation_factor)

    if random.random() < 0.2:
        sigma = random.uniform(0.1, 1.0)
        before = tf.gaussian_blur(before, kernel_size=[3, 3], sigma=[sigma, sigma])
        after = tf.gaussian_blur(after, kernel_size=[3, 3], sigma=[sigma, sigma])

    return _to_tensor_and_normalize(before, after, change)


def images_transforms(before, after, change, input_size=DEFAULT_INPUT_SIZE):
    return imagestransforms(before, after, change, input_size=input_size)


def images_transforms_(before, after, change, input_size=DEFAULT_INPUT_SIZE):
    before, after, change = _resize_triplet(before, after, change, input_size)
    return _to_tensor_and_normalize(before, after, change)


class SYSUCDDataset(torch.utils.data.Dataset):
    def __init__(self, mode='train', root=None, input_size=DEFAULT_INPUT_SIZE):
        self.mode = mode.lower()
        self.root = _resolve_root(root)
        self.input_size = input_size

        (
            self.train_dataset_before,
            self.train_dataset_after,
            self.train_dataset_change,
            self.test_dataset_before,
            self.test_dataset_after,
            self.test_dataset_change,
        ) = read_images(self.root)

        if self.mode == 'train':
            self.before_paths = self.train_dataset_before
            self.after_paths = self.train_dataset_after
            self.change_paths = self.train_dataset_change
            print('SYSU-CD train set loaded: ' + str(len(self.before_paths)) + ' images')
        elif self.mode in ('test', 'val'):
            self.before_paths = self.test_dataset_before
            self.after_paths = self.test_dataset_after
            self.change_paths = self.test_dataset_change
            print('SYSU-CD test set loaded: ' + str(len(self.before_paths)) + ' images')
        else:
            raise ValueError("mode must be 'train', 'test', or 'val'")

        self._validate()

    def _validate(self):
        if not self.before_paths:
            raise RuntimeError(
                'SYSUCDDataset: no matched samples found.\n'
                f'root={self.root}\n'
                'Expected structure: train/A, train/B, train/label or train/OUT; '
                'test/A, test/B, test/label or test/OUT.'
            )
        if not (len(self.before_paths) == len(self.after_paths) == len(self.change_paths)):
            raise RuntimeError(
                'SYSUCDDataset: matched path counts are inconsistent.\n'
                f'A={len(self.before_paths)}, B={len(self.after_paths)}, label={len(self.change_paths)}'
            )

    def __getitem__(self, item):
        before = Image.open(self.before_paths[item]).convert('RGB')
        after = Image.open(self.after_paths[item]).convert('RGB')
        change = Image.open(self.change_paths[item]).convert('L')

        if self.mode == 'train':
            return images_transforms(before, after, change, input_size=self.input_size)
        return images_transforms_(before, after, change, input_size=self.input_size)

    def __len__(self):
        return len(self.before_paths)


if __name__ == '__main__':
    train_data = SYSUCDDataset(mode='train')
    before, after, change = train_data[0]
    print(before.shape, after.shape, change.shape)

    test_data = SYSUCDDataset(mode='test')
    before, after, change = test_data[0]
    print(before.shape, after.shape, change.shape)
