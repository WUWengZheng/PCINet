import os
import sys
from dataclasses import dataclass
from typing import List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from . import MobileNetV2
except ImportError:
    sys.path.append(os.path.dirname(__file__))
    import MobileNetV2


class Double_conv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)


class Channel_Attention(nn.Module):
    def __init__(self, in_ch, reduction=4):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        mip = max(8, in_ch // reduction)
        self.fc1 = nn.Conv2d(in_ch, mip, 1, bias=False)
        self.relu1 = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(2 * mip, in_ch, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        residual = x
        avg = self.relu1(self.fc1(self.avg_pool(x)))
        max_value = self.relu1(self.fc1(self.max_pool(x)))
        x_ch = torch.cat([avg, max_value], dim=1)
        out = self.sigmoid(self.fc2(x_ch))
        return residual * out


class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super().__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)


class CoordChannelAtt(nn.Module):
    def __init__(self, inp, reduction=4):
        super().__init__()
        self.cha = Channel_Attention(inp, reduction=reduction)
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)
        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.conv1_ = nn.Conv2d(mip, inp, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        identity = x
        cha = self.cha(x)

        _, _, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)
        y = self.conv1_(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.sigmoid(x_h)
        a_w = self.sigmoid(x_w)
        out = identity * a_w * a_h
        return out + cha


class PMFFMCore(nn.Module):
    def __init__(self, in_d=None, out_d=64):
        super().__init__()
        if in_d is None:
            in_d = [16, 24, 32, 96, 320]
        self.in_d = in_d
        self.mid_d = out_d // 2
        self.out_d = out_d

        self.step1_c1_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(16, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
        )
        self.step1_c2_Conv = nn.Sequential(
            nn.Conv2d(24, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
        )
        self.step1_c3_Conv = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear'),
            nn.Conv2d(32, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
        )
        self.step1_c4_Conv = nn.Sequential(
            nn.Upsample(scale_factor=4, mode='bilinear'),
            nn.Conv2d(96, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
        )
        self.step1_c5_Conv = nn.Sequential(
            nn.Upsample(scale_factor=8, mode='bilinear'),
            nn.Conv2d(320, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
        )
        self.step1_conv = nn.Sequential(
            nn.Conv2d(160, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
            nn.Conv2d(32, 32, 3, 1, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=False),
        )

        self.step2_c1_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(16, 64, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
        )
        self.step2_c2_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(32, 64, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
        )
        self.step2_c3_Conv = nn.Sequential(
            nn.Conv2d(32, 64, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
        )
        self.step2_c4_Conv = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear'),
            nn.Conv2d(96, 64, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
        )
        self.step2_c5_Conv = nn.Sequential(
            nn.Upsample(scale_factor=4, mode='bilinear'),
            nn.Conv2d(320, 64, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
        )
        self.step2_Conv = nn.Sequential(
            nn.Conv2d(320, 64, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
            nn.Conv2d(64, 64, 3, 1, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=False),
        )

        self.step3_c1_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(16, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
        )
        self.step3_c2_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(32, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
        )
        self.step3_c3_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(64, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
        )
        self.step3_c4_Conv = nn.Sequential(
            nn.Conv2d(96, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
        )
        self.step3_c5_Conv = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear'),
            nn.Conv2d(320, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
        )
        self.step3_Conv = nn.Sequential(
            nn.Conv2d(640, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
            nn.Conv2d(128, 128, 3, 1, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=False),
        )

        self.step4_c1_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(16, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
        )
        self.step4_c2_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(32, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
        )
        self.step4_c3_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(64, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
        )
        self.step4_c4_Conv = nn.Sequential(
            nn.Upsample(scale_factor=0.5, mode='bilinear'),
            nn.Conv2d(128, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
        )
        self.step4_c5_Conv = nn.Sequential(
            nn.Conv2d(320, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
        )
        self.step4_Conv = nn.Sequential(
            nn.Conv2d(1280, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
            nn.Conv2d(256, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=False),
        )

    def forward(self, c1, c2, c3, c4, c5):
        c1_step1 = self.step1_c1_Conv(c1)
        c2_step1 = self.step1_c2_Conv(c2)
        c3_step1 = self.step1_c3_Conv(c3)
        c4_step1 = self.step1_c4_Conv(c4)
        c5_step1 = self.step1_c5_Conv(c5)
        s1 = self.step1_conv(torch.cat([c1_step1, c2_step1, c3_step1, c4_step1, c5_step1], dim=1))

        c1_step2 = self.step2_c1_Conv(c1)
        c2_step2 = self.step2_c2_Conv(s1)
        c3_step2 = self.step2_c3_Conv(c3)
        c4_step2 = self.step2_c4_Conv(c4)
        c5_step2 = self.step2_c5_Conv(c5)
        s2 = self.step2_Conv(torch.cat([c1_step2, c2_step2, c3_step2, c4_step2, c5_step2], dim=1))

        c1_step3 = self.step3_c1_Conv(c1)
        c2_step3 = self.step3_c2_Conv(s1)
        c3_step3 = self.step3_c3_Conv(s2)
        c4_step3 = self.step3_c4_Conv(c4)
        c5_step3 = self.step3_c5_Conv(c5)
        s3 = self.step3_Conv(torch.cat([c1_step3, c2_step3, c3_step3, c4_step3, c5_step3], dim=1))

        c1_step4 = self.step4_c1_Conv(c1)
        c2_step4 = self.step4_c2_Conv(s1)
        c3_step4 = self.step4_c3_Conv(s2)
        c4_step4 = self.step4_c4_Conv(s3)
        c5_step4 = self.step4_c5_Conv(c5)
        s4 = self.step4_Conv(torch.cat([c1_step4, c2_step4, c3_step4, c4_step4, c5_step4], dim=1))
        return s1, s2, s3, s4


class LKABlock(nn.Module):
    def __init__(self, in_channels, compress_ratio=4):
        super().__init__()
        mid_channels = max(8, in_channels // compress_ratio)
        self.proj_1 = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=1, bias=False),
            nn.GroupNorm(1, mid_channels),
            nn.ReLU(inplace=True),
        )
        self.dw5x5 = nn.Sequential(
            nn.Conv2d(
                mid_channels,
                mid_channels,
                kernel_size=5,
                stride=1,
                padding=2,
                groups=mid_channels,
                bias=False,
            ),
            nn.GroupNorm(1, mid_channels),
        )
        self.dw7x7_d3 = nn.Sequential(
            nn.Conv2d(
                mid_channels,
                mid_channels,
                kernel_size=7,
                stride=1,
                padding=9,
                groups=mid_channels,
                dilation=3,
                bias=False,
            ),
            nn.GroupNorm(1, mid_channels),
        )
        self.pw = nn.Sequential(
            nn.Conv2d(mid_channels, in_channels, kernel_size=1, bias=False),
            nn.GroupNorm(1, in_channels),
        )
        self.ffn = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=1, bias=False),
            nn.GroupNorm(1, mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, in_channels, kernel_size=1, bias=False),
            nn.GroupNorm(1, in_channels),
        )

    def forward(self, x):
        residual = x
        attn = self.proj_1(x)
        attn = self.dw5x5(attn)
        attn = self.dw7x7_d3(attn)
        attn = self.pw(attn)
        attn = torch.sigmoid(attn)
        out = residual * attn + residual
        return out + self.ffn(out)


class MFREM(nn.Module):
    """
    Multi-scale Feature Reorganization and Enhancement Module.

    It reorganizes five-level backbone features into four decoder scales and
    enhances deep semantic features with large-kernel context.
    """
    def __init__(self, in_channels=None, out_d=64):
        super().__init__()
        self.pmffm = PMFFMCore(in_channels, out_d)
        self.deep_context3 = LKABlock(128)
        self.deep_context4 = LKABlock(256)

    def forward(self, features):
        f1, f2, f3, f4 = self.pmffm(*features)
        f3 = f3 + self.deep_context3(f3)
        f4 = f4 + self.deep_context4(f4)
        return f1, f2, f3, f4


class CBAM_Channel_Attention(nn.Module):
    def __init__(self, in_ch, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        hidden = in_ch // reduction
        self.fc1 = nn.Conv2d(in_ch, hidden, 1, bias=False)
        self.relu1 = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(hidden, in_ch, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_value = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        return self.sigmoid(avg + max_value)


class Spatial_Attention(nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avg_out, max_out], dim=1)
        return self.sigmoid(self.conv1(out))


class CBAM_Attention(nn.Module):
    def __init__(self, in_ch, reduction=16):
        super().__init__()
        self.cha = CBAM_Channel_Attention(in_ch, reduction=reduction)
        self.spa = Spatial_Attention()
        self.conv = nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch, bias=False)
        self.bn = nn.BatchNorm2d(in_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        out = self.cha(x) * x
        out = self.bn(self.conv(out)) + out
        out = self.spa(out) * out
        return self.relu(out)


class MSConv3x3(nn.Module):
    def __init__(self, in_ch, dilation=3):
        super().__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, 1, 1, 1, 1, False),
            nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, 1, dilation, dilation, 1, False),
            nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(2 * in_ch, in_ch, 1, bias=False),
            nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        y1 = self.conv1(x)
        y2 = self.conv2(x)
        return self.conv3(torch.cat([y1, y2], dim=1))


class My_Attention(nn.Module):
    def __init__(self, in_ch, reduction=16):
        super().__init__()
        self.cbam = CBAM_Attention(in_ch, reduction=reduction)
        self.msconv = MSConv3x3(in_ch, dilation=3)
        self.attention = nn.Sequential(
            nn.Conv2d(in_ch * 2, 1, kernel_size=1),
            nn.BatchNorm2d(1),
            nn.Sigmoid(),
        )
        self.conv1 = nn.Sequential(
            nn.Conv2d(2 * in_ch, in_ch, 1),
            nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True),
        )
        self.conv1_ = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 1),
            nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        out = self.cbam(x)
        out = torch.cat([out, x], dim=1)
        out = out * self.attention(out)
        out = self.conv1(out)
        out = self.msconv(out)
        deepflow = out + x
        out = self.conv1_(deepflow)
        return out, deepflow


class SupervisionAttentionModule(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.SA_Block = CoordChannelAtt(in_channels)
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )
        self.conv1_ = nn.Sequential(
            nn.Conv2d(2 * in_channels, in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )
        self.dwconv = nn.Sequential(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size=3,
                stride=1,
                padding=1,
                groups=in_channels,
            ),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        mask_a = self.conv1(x)
        mask_a1 = self.dwconv(mask_a)
        mask_a_ = self.SA_Block(mask_a)
        mask_b_ = self.SA_Block(mask_a1)
        mask = torch.cat([mask_a_, mask_b_], 1)
        mask_ = self.conv1_(mask)
        mask_b1 = self.dwconv(mask_)
        deep_flow = mask_a + mask_b1
        out = self.conv1(deep_flow)
        return out, deep_flow


@dataclass
class CrossChangeResult:
    change: torch.Tensor
    prior: Optional[torch.Tensor] = None


@dataclass
class DecoderOutputBundle:
    main: torch.Tensor
    aux1: torch.Tensor
    aux2: torch.Tensor
    aux3: torch.Tensor
    prior_list: Optional[List[torch.Tensor]] = None

    def as_tuple(self):
        if self.prior_list is None:
            return self.main, self.aux1, self.aux2, self.aux3
        return self.main, self.aux1, self.aux2, self.aux3, self.prior_list


class ConvBNReLU(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=None):
        if padding is None:
            padding = kernel_size // 2
        super().__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=None):
        super().__init__()
        if padding is None:
            padding = kernel_size // 2
        self.conv = nn.Sequential(
            nn.Conv2d(
                in_channels, in_channels, kernel_size, stride, padding,
                groups=in_channels, bias=False
            ),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)


class PCIM(nn.Module):
    """
    Prior-guided Correlation Interaction Module.

    Input:  fa/fb [B, C, H, W]
    Output: change feature [B, C, H, W], same scale and channels.
    """
    def __init__(self, channels):
        super().__init__()
        mid = max(8, channels // 4)

        self.reduce_diff = ConvBNReLU(channels, mid, kernel_size=1, padding=0)
        self.reduce_prod = ConvBNReLU(channels, mid, kernel_size=1, padding=0)
        self.conv_gate = nn.Sequential(
            DepthwiseSeparableConv(mid * 2 + 1, mid, kernel_size=3),
            nn.Conv2d(mid, channels, kernel_size=1),
            nn.Sigmoid(),
        )

        self.conv_a = nn.Sequential(
            ConvBNReLU(channels * 3, channels, kernel_size=1, padding=0),
            DepthwiseSeparableConv(channels, channels, kernel_size=3),
        )
        self.conv_b = nn.Sequential(
            ConvBNReLU(channels * 3, channels, kernel_size=1, padding=0),
            DepthwiseSeparableConv(channels, channels, kernel_size=3),
        )

        self.fuse = nn.Sequential(
            ConvBNReLU(channels * 4, channels, kernel_size=1, padding=0),
            DepthwiseSeparableConv(channels, channels, kernel_size=3),
        )

    def forward(self, fa, fb, return_prior=False):
        assert fa.shape == fb.shape, f'PCIM shape mismatch: {fa.shape} vs {fb.shape}'
        diff = torch.abs(fa - fb)
        prod = fa * fb

        fa_norm = F.normalize(fa, p=2, dim=1, eps=1e-6)
        fb_norm = F.normalize(fb, p=2, dim=1, eps=1e-6)
        corr = torch.sum(fa_norm * fb_norm, dim=1, keepdim=True)
        change_prior_raw = torch.clamp((1.0 - corr) / 2.0, 0.0, 1.0)

        gate_input = torch.cat([
            self.reduce_diff(diff),
            self.reduce_prod(prod),
            change_prior_raw,
        ], dim=1)
        gate = self.conv_gate(gate_input)

        fa_refine = fa + gate * self.conv_a(torch.cat([fa, fb, diff], dim=1))
        fb_refine = fb + gate * self.conv_b(torch.cat([fb, fa, diff], dim=1))

        change = torch.abs(fa_refine - fb_refine)
        sim = fa_refine * fb_refine
        out = self.fuse(torch.cat([change, sim, diff, gate], dim=1))
        assert out.shape == fa.shape, f'PCIM output shape mismatch: {out.shape} vs {fa.shape}'
        if return_prior:
            return out, change_prior_raw
        return out


class PSAD(nn.Module):
    """
    Progressive Supervised Attention Decoder.

    It progressively fuses four-scale change features and produces one main
    prediction plus three auxiliary predictions.
    """
    def __init__(self, num_classes=2):
        super().__init__()
        self.up4 = nn.Sequential(
            Double_conv(256, 128),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
        )
        self.up3 = nn.Sequential(
            Double_conv(128, 64),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
        )
        self.up2 = nn.Sequential(
            Double_conv(64, 32),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
        )
        self.up1 = nn.Sequential(
            Double_conv(224, 112),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
        )

        self.sp1 = SupervisionAttentionModule(64)
        self.sp2 = My_Attention(128)
        self.sp3 = My_Attention(256)

        self.output_aux_3 = nn.Sequential(
            nn.Conv2d(256, 128, kernel_size=1),
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            nn.Dropout2d(0.3),
            nn.Conv2d(128, num_classes, kernel_size=1),
        )
        self.output_aux_2 = nn.Sequential(
            nn.Conv2d(128, 64, kernel_size=1),
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            nn.Dropout2d(0.3),
            nn.Conv2d(64, num_classes, kernel_size=1),
        )
        self.output_aux_1 = nn.Sequential(
            nn.Conv2d(64, 32, kernel_size=1),
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Dropout2d(0.3),
            nn.Conv2d(32, num_classes, kernel_size=1),
        )
        self.output = nn.Sequential(
            nn.Conv2d(112, 56, kernel_size=1, bias=False),
            nn.BatchNorm2d(56),
            nn.ReLU(True),
            nn.Dropout2d(0.3),
            nn.Conv2d(56, num_classes, kernel_size=1, bias=False),
        )

    def forward(self, d1, d2, d3, d4):
        sp3, aux3 = self.sp3(d4)
        up4 = self.up4(sp3)
        aux_3 = self.output_aux_3(aux3)
        assert up4.shape[2:] == d3.shape[2:], f'up4 {up4.shape} vs d3 {d3.shape}'

        add3 = d3 + up4
        sp2, aux2 = self.sp2(add3)
        up3 = self.up3(sp2)
        aux_2 = self.output_aux_2(aux2)
        assert up3.shape[2:] == d2.shape[2:], f'up3 {up3.shape} vs d2 {d2.shape}'

        add2 = d2 + up3
        sp1, aux1 = self.sp1(add2)
        up2 = self.up2(sp1)
        aux_1 = self.output_aux_1(aux1)
        assert up2.shape[2:] == d1.shape[2:], f'up2 {up2.shape} vs d1 {d1.shape}'

        add1 = d1 + up2
        decoder_fuse = torch.cat([
            F.interpolate(add3, add1.shape[2:], mode='bilinear', align_corners=True),
            F.interpolate(add2, add1.shape[2:], mode='bilinear', align_corners=True),
            add1,
        ], dim=1)
        assert decoder_fuse.shape[1] == 224, (
            f'decoder concat channels expected 224, got {decoder_fuse.shape[1]}'
        )

        main = self.output(self.up1(decoder_fuse))
        return DecoderOutputBundle(main=main, aux1=aux_1, aux2=aux_2, aux3=aux_3)


class PCINet(nn.Module):
    """
    Prior-guided Correlation Interaction Network.

    Keeps the Siamese MobileNetV2 + MFREM + PCIM + PSAD contract:
    returns main_pred, aux1, aux2, aux3 where each is [B, num_classes, H, W].
    """
    def __init__(
        self,
        num_classes=2,
        use_prior_aux_loss=False,
    ):
        super().__init__()
        self.use_prior_aux_loss = use_prior_aux_loss

        self.backbone = MobileNetV2.mobilenet_v2(pretrained=True)
        channels = [16, 24, 32, 96, 320]
        decoder_channels = [32, 64, 128, 256]

        self.mfrem = MFREM(channels, 64)
        self.pcim1 = PCIM(decoder_channels[0])
        self.pcim2 = PCIM(decoder_channels[1])
        self.pcim3 = PCIM(decoder_channels[2])
        self.pcim4 = PCIM(decoder_channels[3])
        self.psad = PSAD(num_classes)

    def _encode_siamese_features(self, img1, img2):
        a_features = self.backbone(img1)
        b_features = self.backbone(img2)
        return a_features, b_features

    def _apply_mfrem(self, features):
        return self.mfrem(features)

    def _cross_change(self, module, fa, fb):
        if self.use_prior_aux_loss:
            change, prior = module(fa, fb, return_prior=True)
            return CrossChangeResult(change=change, prior=prior)
        return CrossChangeResult(change=module(fa, fb))

    def _compute_change_pyramid(self, a_features, b_features):
        cross_results = [
            self._cross_change(self.pcim1, a_features[0], b_features[0]),
            self._cross_change(self.pcim2, a_features[1], b_features[1]),
            self._cross_change(self.pcim3, a_features[2], b_features[2]),
            self._cross_change(self.pcim4, a_features[3], b_features[3]),
        ]
        fused_changes = [result.change for result in cross_results]
        return cross_results, fused_changes

    def _decode_change_pyramid(self, d1, d2, d3, d4):
        return self.psad(d1, d2, d3, d4)

    def _resize_predictions(self, outputs, output_size):
        outputs.main = F.interpolate(
            outputs.main, size=output_size, mode='bilinear', align_corners=True
        )
        outputs.aux1 = F.interpolate(
            outputs.aux1, size=output_size, mode='bilinear', align_corners=True
        )
        outputs.aux2 = F.interpolate(
            outputs.aux2, size=output_size, mode='bilinear', align_corners=True
        )
        outputs.aux3 = F.interpolate(
            outputs.aux3, size=output_size, mode='bilinear', align_corners=True
        )
        return outputs

    def _attach_prior_outputs(self, outputs, cross_results):
        if self.use_prior_aux_loss:
            outputs.prior_list = [result.prior for result in cross_results]
        return outputs

    def _assert_pyramid_channels(self, a_features, b_features):
        expected_channels = (32, 64, 128, 256)
        for idx, channels in enumerate(expected_channels):
            assert a_features[idx].shape[1] == b_features[idx].shape[1] == channels

    def forward(self, img1, img2):
        h, w = img1.shape[2:]

        a_features, b_features = self._encode_siamese_features(img1, img2)

        # MFREM maps backbone channels [16,24,32,96,320]
        # to enhanced decoder channels [32,64,128,256].
        a_features = self._apply_mfrem(a_features)
        b_features = self._apply_mfrem(b_features)
        self._assert_pyramid_channels(a_features, b_features)

        cross_results, fused_changes = self._compute_change_pyramid(a_features, b_features)
        for change_feature, ref_feature in zip(fused_changes, a_features):
            assert change_feature.shape[1:] == ref_feature.shape[1:]

        outputs = self._decode_change_pyramid(*fused_changes)
        outputs = self._resize_predictions(outputs, (h, w))
        outputs = self._attach_prior_outputs(outputs, cross_results)

        assert outputs.main.shape[2:] == (h, w), (
            f'main output size {outputs.main.shape[2:]} != {(h, w)}'
        )
        assert outputs.aux1.shape[2:] == (h, w)
        assert outputs.aux2.shape[2:] == (h, w)
        assert outputs.aux3.shape[2:] == (h, w)
        return outputs.as_tuple()


if __name__ == '__main__':
    x1 = torch.randn(2, 3, 256, 256)
    x2 = torch.randn(2, 3, 256, 256)
    expected_prior_shapes = [
        (2, 1, 64, 64),
        (2, 1, 32, 32),
        (2, 1, 16, 16),
        (2, 1, 8, 8),
    ]

    for use_prior_aux_loss in [False, True]:
        model = PCINet(num_classes=2, use_prior_aux_loss=use_prior_aux_loss)
        model.eval()
        with torch.no_grad():
            outputs = model(x1, x2)

        if not use_prior_aux_loss:
            assert len(outputs) == 4
            main, aux1, aux2, aux3 = outputs
            for out in [main, aux1, aux2, aux3]:
                print(f'prior_aux={use_prior_aux_loss} output: {tuple(out.shape)}')
                assert out.shape == (2, 2, 256, 256)
        else:
            assert len(outputs) == 5
            main, aux1, aux2, aux3, prior_list = outputs
            assert len(prior_list) == 4
            for out in [main, aux1, aux2, aux3]:
                print(f'prior_aux={use_prior_aux_loss} output: {tuple(out.shape)}')
                assert out.shape == (2, 2, 256, 256)
            for prior, expected_shape in zip(prior_list, expected_prior_shapes):
                print(f'prior_aux={use_prior_aux_loss} prior: {tuple(prior.shape)}')
                assert prior.shape == expected_shape

    print('PCINet forward shape tests passed.')
